package com.mapnaom.ticketingplatform.dto.access;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Set;

public record PermissionStatusDto(
        @JsonProperty("ACCESS") Access ACCESS,
        @JsonProperty("TICKET") Ticket TICKET,
        @JsonProperty("CUSTOMER") Customer CUSTOMER,
        @JsonProperty("TEAM_MEMBER") TeamMember TEAM_MEMBER,
        @JsonProperty("TEAM_MANAGER") TeamManager TEAM_MANAGER,
        @JsonProperty("SLA") Sla SLA
) {
    public static PermissionStatusDto from(Set<String> permissionCodes) {
        return new PermissionStatusDto(
                new Access(new AccessAdmin(has(permissionCodes, "ACCESS_ADMIN"))),
                new Ticket(
                        has(permissionCodes, "TICKET_CREATE"),
                        has(permissionCodes, "TICKET_READ"),
                        has(permissionCodes, "TICKET_UPDATE"),
                        has(permissionCodes, "TICKET_DELETE")),
                new Customer(
                        has(permissionCodes, "CUSTOMER_READ"),
                        has(permissionCodes, "CUSTOMER_CREATE"),
                        has(permissionCodes, "CUSTOMER_UPDATE"),
                        has(permissionCodes, "CUSTOMER_DELETE")),
                new TeamMember(
                        has(permissionCodes, "TEAM_MEMBER_READ"),
                        has(permissionCodes, "TEAM_MEMBER_UPDATE")),
                new TeamManager(has(permissionCodes, "TEAM_MANAGER_READ")),
                new Sla(
                        has(permissionCodes, "SLA_READ"),
                        has(permissionCodes, "SLA_CREATE"),
                        has(permissionCodes, "SLA_UPDATE"),
                        has(permissionCodes, "SLA_DELETE"))
        );
    }

    private static boolean has(Set<String> permissionCodes, String permissionCode) {
        return permissionCodes != null && permissionCodes.contains(permissionCode);
    }

    public record Access(@JsonProperty("ADMIN") AccessAdmin ADMIN) {
    }

    public record AccessAdmin(@JsonProperty("get") boolean get) {
    }

    public record Ticket(
            @JsonProperty("CREATE") boolean CREATE,
            @JsonProperty("READ") boolean READ,
            @JsonProperty("UPDATE") boolean UPDATE,
            @JsonProperty("DELETE") boolean DELETE
    ) {
    }

    public record Customer(
            @JsonProperty("READ") boolean READ,
            @JsonProperty("CREATE") boolean CREATE,
            @JsonProperty("UPDATE") boolean UPDATE,
            @JsonProperty("DELETE") boolean DELETE
    ) {
    }

    public record TeamMember(
            @JsonProperty("READ") boolean READ,
            @JsonProperty("UPDATE") boolean UPDATE
    ) {
    }

    public record TeamManager(@JsonProperty("READ") boolean READ) {
    }

    public record Sla(
            @JsonProperty("READ") boolean READ,
            @JsonProperty("CREATE") boolean CREATE,
            @JsonProperty("UPDATE") boolean UPDATE,
            @JsonProperty("DELETE") boolean DELETE
    ) {
    }
}
