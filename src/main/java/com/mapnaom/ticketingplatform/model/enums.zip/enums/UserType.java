package com.mapnaom.ticketingplatform.model.enums;

public enum UserType {
    CUSTOMER,
    TEAM_MEMBER,
    TEAM_MANAGER
}
